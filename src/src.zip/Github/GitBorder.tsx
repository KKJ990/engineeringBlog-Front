import {useState,useEffect} from "react";
import { Button } from "react-bootstrap"


const GitBorder=()=>{
  const [post, setMessage] = useState([]);

    useEffect(() => {
        fetch("/hello")
            .then((response) => {
                return response.json();
            })
            .then(function (data) {
                setMessage(data);
            });
    }, []);






  return(
    <div>
    <div>
      <h3 style={{fontWeight:"bolder"}}>GitHub</h3>
    </div>


      <hr></hr>
      <div className="posting">
        <div className="posttitle" style={{fontWeight:"bold"}}>
        제목
        </div>
        <div className="postdetail" style={{fontWeight:"bold"}}>
        내용
        </div>
        <div className="postdate" style={{fontWeight:"bold"}}>
        날짜
        </div>
        </div>  
    <hr></hr>




    <div className="posting">
      <div className="posttitle">
      Test
      </div>
      <div className="postdetail">
        Test
      </div>
      <div className="postdate">
        Test
      </div>
    </div>


    <div className="postbottom">

    <Button className="postbutton">등록</Button>
    <Button className="deletebutton">삭제</Button>
    </div>





    </div>

  )


}
export default GitBorder