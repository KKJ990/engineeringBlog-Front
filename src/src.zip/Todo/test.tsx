const Test=()=>{

  console.log("테스트")

return(
  
<div>
  <h2>화면전환</h2>
</div>
)

}

export default Test;