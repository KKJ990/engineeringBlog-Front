import AddTodoList from "./AddTodoList"

const TodoMain=()=>{

return(


      <div className="todo-post">
          <AddTodoList/>
      </div>



  );
}
export default TodoMain