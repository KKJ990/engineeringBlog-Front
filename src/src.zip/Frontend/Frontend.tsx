import {useEffect, useState} from "react";

const Frontend=()=> {
    const [message, setMessage] = useState([]);

    useEffect(() => {
        fetch("/hello")
            .then((response) => {
                return response.json();
            })
            .then(function (data) {
                setMessage(data);
            });
    }, []);

    return (
        <div>
        <p>
           Edit <code>src/App.js</code> and save to reload.
        </p>
        <ul>
          {message.map((text, index) => <li key={`${index}-${text}`}>{text}</li>)}
        </ul>
        </div>
    );
}
export default Frontend