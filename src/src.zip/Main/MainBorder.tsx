
import Frontend from "../Frontend/Frontend"
import RouteMain from "./RouteMain"


const MainBorder=()=>{


  return(

    <div>
      <RouteMain/>
      <Frontend/>
    </div>

  )






}
export default MainBorder